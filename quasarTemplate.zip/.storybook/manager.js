// https://ithelp.ithome.com.tw/articles/10243609

import { addons } from '@storybook/addons';

addons.setConfig({
    sidebar: {
        showRoots: true
    }
});
