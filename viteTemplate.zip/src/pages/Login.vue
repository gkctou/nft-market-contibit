<template>
    <div>
        <LoginCard email="" password="" />
    </div>
</template>

<script setup lang="ts">
import LoginCard from '../combinations/LoginCard.vue';
</script>
