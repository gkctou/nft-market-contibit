<template>
    <div>
        <h1>TestComponent</h1>
    </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    setup() {
        

        return {}
    }
})
</script>

<style scoped>

</style>